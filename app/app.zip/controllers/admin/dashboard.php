<?php
// Inicia a sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// BLOQUEIO DE SEGURANÇA: Apenas admins logados podem ver
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] != 1) {
    header("Location: ../usuario/login.php?erro=acessonegado");
    exit();
}

// Inclui a conexão com o banco de dados
require_once '../../config/database.php';

// Pega o nome do admin da sessão
$nome_admin = $_SESSION['usuario_nome'];

// =================================================================
//  INÍCIO DAS CONSULTAS AO BANCO DE DADOS PARA DADOS REAIS
// =================================================================

// --- KPI 1: Agendamentos para Hoje ---
$hoje = date('Y-m-d');
$stmt1 = $conn->prepare("SELECT COUNT(agen_id) as total FROM agendamento WHERE agen_data_a = ?");
$stmt1->bind_param("s", $hoje);
$stmt1->execute();
$agendamentos_hoje = $stmt1->get_result()->fetch_assoc()['total'] ?? 0;
$stmt1->close();

// --- KPI 2: Faturamento Previsto para Hoje ---
$stmt2 = $conn->prepare("
    SELECT SUM(c.corte_preco) as faturamento 
    FROM agendamento a
    JOIN corte c ON a.corte_id = c.corte_id
    WHERE a.agen_data_a = ?
");
$stmt2->bind_param("s", $hoje);
$stmt2->execute();
$faturamento_previsto = $stmt2->get_result()->fetch_assoc()['faturamento'] ?? 0;
$stmt2->close();

// --- KPI 3: Novos Clientes no Mês Atual ---
// (Requer a coluna 'usuario_data_cadastro' na tabela 'usuario')
$mes_atual = date('m');
$ano_atual = date('Y');
$stmt3 = $conn->prepare("SELECT COUNT(usuario_id) as novos FROM usuario WHERE MONTH(usuario_data_cadastro) = ? AND YEAR(usuario_data_cadastro) = ?");
$stmt3->bind_param("ss", $mes_atual, $ano_atual);
$stmt3->execute();
$novos_clientes_mes = $stmt3->get_result()->fetch_assoc()['novos'] ?? 0;
$stmt3->close();

// --- Tabela: 5 Próximos Agendamentos (de hoje em diante) ---
$stmt4 = $conn->prepare("
    SELECT a.agen_hora_a, a.agen_data_a, u.usuario_nome, c.corte_nome
    FROM agendamento a
    JOIN usuario u ON a.usuario_id = u.usuario_id
    JOIN corte c ON a.corte_id = c.corte_id
    WHERE a.agen_data_a >= ?
    ORDER BY a.agen_data_a ASC, a.agen_hora_a ASC
    LIMIT 5
");
$stmt4->bind_param("s", $hoje);
$stmt4->execute();
$proximos_agendamentos = $stmt4->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt4->close();


// =================================================================
//  NOVA LÓGICA: CONSULTA PARA O GRÁFICO
// =================================================================
$chart_labels = [];
$chart_data = [];
$dias_pt = ['Sun' => 'Dom', 'Mon' => 'Seg', 'Tue' => 'Ter', 'Wed' => 'Qua', 'Thu' => 'Qui', 'Fri' => 'Sex', 'Sat' => 'Sáb'];

// Loop para os últimos 7 dias (de 6 dias atrás até hoje)
for ($i = 6; $i >= 0; $i--) {
    // Calcula a data para cada dia do loop
    $data_loop = date('Y-m-d', strtotime("-$i days"));
    
    // Pega o nome do dia da semana em inglês (ex: 'Mon')
    $dia_semana_en = date('D', strtotime($data_loop));
    
    // Traduz e adiciona ao array de labels do gráfico
    $chart_labels[] = $dias_pt[$dia_semana_en];

    // Prepara a consulta para contar agendamentos naquela data específica
    $stmt5 = $conn->prepare("SELECT COUNT(agen_id) as total FROM agendamento WHERE agen_data_a = ?");
    $stmt5->bind_param("s", $data_loop);
    $stmt5->execute();
    $total_dia = $stmt5->get_result()->fetch_assoc()['total'] ?? 0;
    
    // Adiciona o total ao array de dados do gráfico
    $chart_data[] = $total_dia;
    $stmt5->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Roxinho's Barber</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Cole o CSS da resposta anterior aqui (o CSS com o tema roxo e responsivo) */
        :root { --cor-fundo: #181828; --cor-fundo-secundario: #1f1f2e; --cor-texto: #f0f0f0; --cor-primaria: #d633ff; --cor-secundaria: #e6b800; } body { font-family: 'Barlow Condensed', sans-serif; background-color: var(--cor-fundo); color: var(--cor-texto); } .sidebar { position: fixed; top: 0; left: 0; bottom: 0; z-index: 1000; width: 250px; padding: 20px; background-color: #000; display: flex; flex-direction: column; transition: transform 0.3s ease; } .sidebar .logo { font-size: 1.8rem; font-weight: bold; color: var(--cor-primaria); text-align: center; margin-bottom: 30px; } .sidebar .nav-link { color: var(--cor-texto); font-size: 1.2rem; padding: 10px 15px; margin-bottom: 5px; border-radius: 8px; transition: background-color 0.3s, color 0.3s; } .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: var(--cor-primaria); color: #fff; } .sidebar .logout-link { margin-top: auto; } .main-content { margin-left: 250px; padding: 30px; transition: margin-left 0.3s ease; } .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; } .card-kpi { background-color: var(--cor-fundo-secundario); border: 1px solid #333; border-radius: 12px; padding: 20px; color: var(--cor-texto); } .card-kpi .kpi-icon { font-size: 2.5rem; margin-bottom: 10px; color: var(--cor-primaria); } .card-kpi .kpi-value { font-size: 2rem; font-weight: bold; } .table-dark-custom thead th { color: var(--cor-texto); background-color: var(--cor-primaria); } .mobile-header { display: none; background-color: #000; padding: 10px 15px; align-items: center; } .menu-toggle { font-size: 1.5rem; color: #fff; background: none; border: none; } .overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0,0,0,0.5); z-index: 999; } @media (max-width: 992px) { .sidebar { transform: translateX(-100%); } .sidebar.is-active { transform: translateX(0); } .main-content { margin-left: 0; } .header { display: none; } .mobile-header { display: flex; } .overlay.is-active { display: block; } }
    </style>
</head>
<body>

<div id="overlay" class="overlay"></div>

<div class="sidebar" id="sidebar">
    <div class="logo">ROXINHO'S ADM</div>
    <ul class="nav flex-column"><li class="nav-item"><a class="nav-link active" href="#"><i class="bi bi-house-door-fill me-2"></i> Início</a></li><li class="nav-item"><a class="nav-link" href="#"><i class="bi bi-calendar-check-fill me-2"></i> Agendamentos</a></li>
<li class="nav-item"><a class="nav-link" href="usuarios.php"><i class="bi bi-person me-2"></i> Usuários</a></li></ul>
    <ul class="nav flex-column logout-link"><li class="nav-item"><a class="nav-link" href="../../controllers/logout.php"><i class="bi bi-box-arrow-left me-2"></i> Sair</a></li></ul>
</div>

<div class="main-content" id="main-content">
    
    <div class="mobile-header">
        <button class="menu-toggle" id="menu-toggle"><i class="bi bi-list"></i></button>
        <div class="logo ms-3">ROXINHO'S ADM</div>
    </div>

    <header class="header">
        <div><h2>Dashboard</h2><p class="lead">Bem-vindo(a) de volta, <?php echo htmlspecialchars($nome_admin); ?>!</p></div>
        <a href="#" class="btn btn-purple"><i class="bi bi-plus-circle-fill me-2"></i> Novo Agendamento</a>
    </header>

    <div class="row g-4 mb-4">
        <div class="col-md-4"><div class="card-kpi text-center"><div class="kpi-icon"><i class="bi bi-clock-history"></i></div><div class="kpi-value"><?php echo $agendamentos_hoje; ?></div><div class="kpi-title">Agendamentos para Hoje</div></div></div>
        <div class="col-md-4"><div class="card-kpi text-center"><div class="kpi-icon" style="color:var(--cor-secundaria);"><i class="bi bi-cash-stack"></i></div><div class="kpi-value">R$ <?php echo number_format($faturamento_previsto, 2, ',', '.'); ?></div><div class="kpi-title">Faturamento Previsto (Hoje)</div></div></div>
        <div class="col-md-4"><div class="card-kpi text-center"><div class="kpi-icon" style="color:#00e6e6;"><i class="bi bi-person-plus-fill"></i></div><div class="kpi-value"><?php echo $novos_clientes_mes; ?></div><div class="kpi-title">Novos Clientes (Mês)</div></div></div>
    </div>

    <div class="row g-4">
        <div class="col-lg-7">
            <h4>Próximos 5 Agendamentos</h4>
            <div class="table-responsive"><table class="table table-dark-custom align-middle">
                <thead><tr><th>Data</th><th>Horário</th><th>Cliente</th><th>Serviço</th></tr></thead>
                <tbody>
                    <?php if (empty($proximos_agendamentos)): ?>
                        <tr><td colspan="4" class="text-center p-4">Nenhum agendamento futuro encontrado.</td></tr>
                    <?php else: ?>
                        <?php foreach($proximos_agendamentos as $ag): ?>
                        <tr><td><?php echo date("d/m", strtotime($ag['agen_data_a'])); ?></td><td><?php echo substr($ag['agen_hora_a'], 0, 5); ?></td><td><?php echo htmlspecialchars($ag['usuario_nome']); ?></td><td><?php echo htmlspecialchars($ag['corte_nome']); ?></td></tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table></div>
        </div>

        <div class="col-lg-5">
            <h4>Agendamentos (Últimos 7 dias)</h4>
            <div class="card-kpi"><canvas id="agendamentosChart"></canvas></div>
        </div>
    </div>
</div>

<script>
    // Script para o menu mobile (sem alterações)
    const menuToggle = document.getElementById('menu-toggle'); const sidebar = document.getElementById('sidebar'); const overlay = document.getElementById('overlay');
    menuToggle.addEventListener('click', () => { sidebar.classList.toggle('is-active'); overlay.classList.toggle('is-active'); });
    overlay.addEventListener('click', () => { sidebar.classList.remove('is-active'); overlay.classList.remove('is-active'); });

    // =================================================================
    //  SCRIPT DO GRÁFICO COM DADOS VINDOS DO PHP
    // =================================================================
    const ctx = document.getElementById('agendamentosChart').getContext('2d');
    const agendamentosChart = new Chart(ctx, {
        type: 'bar',
        data: {
            // As labels (Dom, Seg, Ter...) são inseridas aqui pelo PHP
            labels: [<?php echo "'" . implode("','", $chart_labels) . "'"; ?>],
            datasets: [{
                label: 'Nº de Agendamentos',
                // Os dados (número de agendamentos por dia) são inseridos aqui pelo PHP
                data: [<?php echo implode(',', $chart_data); ?>],
                backgroundColor: 'rgba(214, 51, 255, 0.6)',
                borderColor: 'rgba(214, 51, 255, 1)',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, ticks: { color: 'white' }, grid: { color: 'rgba(255, 255, 255, 0.1)' } },
                x: { ticks: { color: 'white' }, grid: { display: false } }
            },
            plugins: { legend: { labels: { color: 'white' } } }
        }
    });
</script>

</body>
</html>