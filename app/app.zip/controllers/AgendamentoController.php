<?php
// controllers/agendamentoController.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['usuario_id'])) { header("Location: ../views/usuario/login.php?erro=agendar"); exit(); }
    $corte_id = filter_input(INPUT_POST, 'corte_id', FILTER_VALIDATE_INT);
    $data_agendamento = $_POST['data_agendamento'] ?? '';
    $hora_agendamento = $_POST['hora_agendamento'] ?? '';
    $usuario_id = $_SESSION['usuario_id'];

    if (!$corte_id || empty($data_agendamento) || empty($hora_agendamento)) { header("Location: ../index.php?agendamento=erro"); exit(); }

    $sql = "INSERT INTO agendamento (agen_data_a, agen_hora_a, usuario_id, corte_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $data_agendamento, $hora_agendamento, $usuario_id, $corte_id);

    if ($stmt->execute()) { header("Location: ../index.php?agendamento=sucesso#inicio"); } else { header("Location: ../index.php?agendamento=erro#servicos"); }
    $stmt->close();
    $conn->close();
} else {
    header("Location: ../index.php"); exit();
}
?>