<?php
// includes/funcoes.php
header('Content-Type: application/json');
require_once '../config/database.php';
$acao = $_GET['acao'] ?? '';

if ($acao == 'carregaCalendario') {
    $ano = filter_input(INPUT_GET, 'ano', FILTER_VALIDATE_INT);
    $mes = filter_input(INPUT_GET, 'mes', FILTER_VALIDATE_INT);
    if (!$ano || !$mes) { echo json_encode(['erro' => 'Ano e mês inválidos']); exit; }

    $primeiroDia = "$ano-$mes-01";
    $ultimoDia = date("Y-m-t", strtotime($primeiroDia));

    $stmtInativos = $conn->prepare("SELECT diaInativo_data_inativa FROM dia_inativo WHERE diaInativo_data_inativa BETWEEN ? AND ?");
    $stmtInativos->bind_param("ss", $primeiroDia, $ultimoDia);
    $stmtInativos->execute();
    $resultadoInativos = $stmtInativos->get_result();
    $diasInativos = [];
    while ($row = $resultadoInativos->fetch_assoc()) { $diasInativos[] = $row['diaInativo_data_inativa']; }
    $stmtInativos->close();

    echo json_encode(['inativos' => $diasInativos]);
    exit;
}

if ($acao == 'buscaHorarios') {
    $data = $_GET['data'] ?? '';
    if (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $data)) { echo json_encode([]); exit; }

    $horariosDisponiveis = ['09:00:00', '10:00:00', '11:00:00', '12:00:00', '14:00:00', '15:00:00', '16:00:00', '17:00:00', '18:00:00'];
    
    $stmtAgendados = $conn->prepare("SELECT agen_hora_a FROM agendamento WHERE agen_data_a = ?");
    $stmtAgendados->bind_param("s", $data);
    $stmtAgendados->execute();
    $resultadoAgendados = $stmtAgendados->get_result();
    $horariosAgendados = [];
    while ($row = $resultadoAgendados->fetch_assoc()) { $horariosAgendados[] = $row['agen_hora_a']; }
    $stmtAgendados->close();

    $horariosLivres = array_diff($horariosDisponiveis, $horariosAgendados);
    $horariosFormatados = [];
    foreach($horariosLivres as $hora) { $horariosFormatados[] = substr($hora, 0, 5); }

    echo json_encode(array_values($horariosFormatados));
    exit;
}
echo json_encode(['erro' => 'Ação não reconhecida']);
?>